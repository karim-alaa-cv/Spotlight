package com.example.spotlight

import android.app.*
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.*
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.*
import android.view.WindowManager.LayoutParams.*

/* ---------- الشاشة المعتمة: كلها سودا إلا شريط القراءة ---------- */
class OverlayView(ctx: Context) : View(ctx) {
    var centerY = 0f
        set(v) { field = v; invalidate() }
    var bandHeight = 400f

    override fun onDraw(c: Canvas) {
        c.save()
        c.clipOutRect(0f, centerY - bandHeight / 2, width.toFloat(), centerY + bandHeight / 2)
        c.drawColor(Color.BLACK)
        c.restore()
    }
}

/* ---------- الـ Service ---------- */
class SpotlightService : Service() {
    private lateinit var wm: WindowManager
    private lateinit var overlay: OverlayView
    private lateinit var handle: View
    companion object { var running = false }

    override fun onBind(i: Intent?): android.os.IBinder? = null

    override fun onCreate() {
        super.onCreate()
        running = true
        startAsForeground()
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        val dm = resources.displayMetrics

        // 1) طبقة التعتيم: بتعدّي اللمس، والشفافية 0.8 هي الحد الأقصى المسموح في أندرويد 12+
        overlay = OverlayView(this).apply {
            bandHeight = dm.heightPixels / 5f
            centerY = dm.heightPixels / 2f
        }
        val ovLp = WindowManager.LayoutParams(
            MATCH_PARENT, MATCH_PARENT, TYPE_APPLICATION_OVERLAY,
            FLAG_NOT_FOCUSABLE or FLAG_NOT_TOUCHABLE or FLAG_LAYOUT_IN_SCREEN or FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply { alpha = 0.8f }
        wm.addView(overlay, ovLp)

        // 2) مقبض صغير على الحافة اليمين بتسحبه لفوق وتحت عشان تحرك الشريط
        val size = (48 * dm.density).toInt()
        handle = View(this).apply {
            background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(0xCC888888.toInt())
            }
        }
        val hLp = WindowManager.LayoutParams(
            size, size, TYPE_APPLICATION_OVERLAY,
            FLAG_NOT_FOCUSABLE or FLAG_LAYOUT_IN_SCREEN or FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.END
            y = (overlay.centerY - size / 2).toInt()
        }
        handle.setOnTouchListener { _, e ->
            if (e.action == MotionEvent.ACTION_MOVE || e.action == MotionEvent.ACTION_DOWN) {
                overlay.centerY = e.rawY
                hLp.y = (e.rawY - size / 2).toInt()
                wm.updateViewLayout(handle, hLp)
            }
            true
        }
        wm.addView(handle, hLp)
    }

    override fun onDestroy() {
        running = false
        runCatching { wm.removeView(overlay) }
        runCatching { wm.removeView(handle) }
        super.onDestroy()
    }

    private fun startAsForeground() {
        val ch = "spotlight"
        getSystemService(NotificationManager::class.java)
            .createNotificationChannel(NotificationChannel(ch, "Spotlight", NotificationManager.IMPORTANCE_LOW))
        val stop = PendingIntent.getService(
            this, 0, Intent(this, SpotlightService::class.java).setAction("STOP"),
            PendingIntent.FLAG_IMMUTABLE
        )
        val n = Notification.Builder(this, ch)
            .setContentTitle("وضع الخصوصية شغال")
            .setSmallIcon(android.R.drawable.ic_lock_idle_lock)
            .setContentIntent(stop) // اضغط على الإشعار لإيقافه
            .build()
        if (Build.VERSION.SDK_INT >= 34)
            startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        else startForeground(1, n)
    }

    override fun onStartCommand(i: Intent?, f: Int, id: Int): Int {
        if (i?.action == "STOP") stopSelf()
        return START_STICKY
    }
}

/* ---------- الشاشة الرئيسية: تطلب إذن الـ overlay وتشغّل الـ Service ---------- */
class MainActivity : Activity() {
    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        if (!Settings.canDrawOverlays(this)) {
            startActivity(
                Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))
            )
        } else if (SpotlightService.running) {
            stopService(Intent(this, SpotlightService::class.java))
        } else {
            if (Build.VERSION.SDK_INT >= 33)
                requestPermissions(arrayOf("android.permission.POST_NOTIFICATIONS"), 1)
            startForegroundService(Intent(this, SpotlightService::class.java))
        }
        finish()
    }
}
